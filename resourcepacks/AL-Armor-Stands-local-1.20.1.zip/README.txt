Correção local: AL's Armor Stands Revamped em Minecraft1.20.1 / Forge

Uso: coloque este overlay acima do pack original de ALtheGatorMC na lista de resource packs.
Requer Entity Model Features e Entity Texture Features (ETF); instalado7.2.5.

O pack oficial só declara Minecraft1.21.8–1.21.11. Seu metadata original não é alterado.
O modelo base e as variantes nomeadas de entidades utilizam CEM tradicional; este patch
corrige apenas a seleção do modelo quando o suporte de armadura tem algum item equipado.

Correção: seis regras nbt.equipment.*.id (estrutura NBT criada no Minecraft1.21.5) são
substituídas pela regra ETF items.1=any; modelos.1=1 continua escolhendo o modelo padrão
quando qualquer slot de armadura ou mão contém item. As regras nomeadas originais7–16
são preservadas e renumeradas2–11 para manter numeração contínua.

Uma conversão literal para nbt.ArmorItems.3.id foi evitada: o bytecode do ETF7.2.5 instalado
retorna o compound do índice numérico sem processar o sufixo id. Existe:true poderia
considerar até um slot vazio existente. ItemProperty implementa items=any lendo
itemsEquipped() e verificando item != null e !item.isEmpty(), cobrindo as duas mãos
mais os quatro slots de armadura e evitando esse problema.

Verificações realizadas: SHA512 do pack original; ZIP/JSON; todos os modelos referidos
existem no pack original; tabela de variantes nomeadas e fallback preservados; classe
ItemProperty do JAR ETF7.2.5 inspecionada por javap e conferida com fonte primária.
Não houve teste visual em jogo neste subtrabalho.

Limitação: os ícones de itens renomeados do arquivo assets/minecraft/items/armor_stand.json
continuam sem suporte em1.20.1. Este patch não instala CIT nem converte os ícones.

Crédito: modelos, texturas e tabela de nomes do pack original são de ALtheGatorMC.
Overlay local para uso pessoal. Não redistribuir assets originais.

Fontes primárias:
https://modrinth.com/resourcepack/als-armor-stands-revamped
https://github.com/Traben-0/Entity_Texture_Features/blob/ETF-Main/src/main/java/traben/entity_texture_features/features/property_reading/properties/etf_properties/ItemProperty.java
https://github.com/Traben-0/Entity_Texture_Features/blob/ETF-Main/src/main/java/traben/entity_texture_features/features/property_reading/properties/optifine_properties/NBTProperty.java
https://www.minecraft.net/pt-br/article/minecraft-java-edition-1-21-5
