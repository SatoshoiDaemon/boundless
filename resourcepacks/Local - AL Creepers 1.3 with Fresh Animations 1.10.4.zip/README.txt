Private local compatibility pack.
Load above Fresh Animations 1.10.4. AL Creepers Revamped 1.3 may be above this pack because it contains textures only.

Creeper, charged Creeper, and Creeper head models derive from official FreshAnimations_v1.9.2.zip by FreshLX. This version matches the eyelid/pupil UV layout documented for AL Creepers Revamped 1.3. Other mobs retain Fresh Animations 1.10.4.
The only geometry-file change removes optional references to 12 missing JPM extension hooks, retaining their empty attachment nodes and animation targets. No textures are included; AL supplies all Creeper textures.

Author/source: https://modrinth.com/resourcepack/fresh-animations/version/8vtPih5h
Terms permit modifications for personal use; this pack is private and must not be redistributed.
